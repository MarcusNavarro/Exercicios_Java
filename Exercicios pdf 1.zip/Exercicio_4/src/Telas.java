import static javax.swing.JOptionPane.*;

class Telas{
	public static void main(String[] args) {
		String nome;
		nome = showInputDialog("digite seu nome:");
		showMessageDialog(null, "boa noite " + nome + "!!");
	}
}