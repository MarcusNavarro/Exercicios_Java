import java.util.Scanner;
import java.lang.Object;
import java.lang.Math;

public class Numeros{
	static Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		double n1;
		double n2;
		System.out.println("digite o primeirto numero");
		n1 = scanner.nextFloat();
		System.out.println("digite o segundo numero");
		n2 = scanner.nextFloat();
		System.out.println(n1*n2);
		System.out.println(n1/n2);
		System.out.println(Math.pow(n1,n2));
		System.out.println(Math.pow(n2,n1));
		System.out.println(Math.sqrt(n1));
		System.out.println(Math.sqrt(n2));
		System.out.println(Math.sqrt(Math.pow(n1,n2)));
		System.out.println(Math.sqrt(n1*n2));
	}
}