import java.util.Scanner;


public class Aluno_ex2{
	static Scanner scanner = new Scanner(System.in);
	public static void main (String[] args) {
		
		String nome;
		int idade;
		int dif_idade;
		double altura;
		double dif_altura;
		System.out.println("Escreva seu nome completo");
		nome = scanner.nextLine();
		System.out.println("Escreva sua idade");
		idade = scanner.nextInt();
		System.out.println("escreva sua altura");
		altura = scanner.nextDouble();
		dif_idade = idade + 1;
		dif_altura = 2 - altura;
		System.out.println(nome + " terá " + dif_idade +" ano que vem e precisará crescer " + dif_altura + " para ter 2 metros");
		
	}
}