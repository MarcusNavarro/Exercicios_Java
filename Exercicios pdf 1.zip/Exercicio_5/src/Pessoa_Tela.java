import static javax.swing.JOptionPane.*;

class Pessoa_Tela{
	public static void main(String[] args) {
		String nome;
		String idade;
		String altura;
		
		nome = showInputDialog("digite seu nome:");
		idade = showInputDialog("digite sua idade");
		int sub_idade;
		sub_idade = (Integer.parseInt(idade) + 1);
		altura = showInputDialog("digite sua altura");
		float sub_altura;
		sub_altura = 2 - (Float.parseFloat(altura));
		showMessageDialog(null, nome +" tera " + sub_idade + " ano que vem e precisa crescer " + sub_altura + " para ter 2 metros");
	}
}