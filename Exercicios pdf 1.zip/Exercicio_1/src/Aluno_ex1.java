public class Aluno_ex1{
	public static void main (String[] args) {
		System.out.println("Marcus Vinicius");
		System.out.println("D97DCB0");
	}
}