import java.util.Scanner;
public class ES{
	static Scanner scanner = new Scanner(System.in);
	public static void print(String msg) {
		System.out.print(msg);
	}
	public static String input(String msg) {
		System.out.print(msg);
		String s;
		s = scanner.nextLine();
		return s;
	}
	public static Double toDouble(String s) {
		double d;
		d = Double.parseDouble(s);
		return d;
	}
	public static int ToInt(String s) {
		int i;
		i = Integer.parseInt(s);
		return i;
	}
}