public class contas {
	public static void main (String[] args) {
		String s;
		float[] saldos;
		saldos = new float [3];
		s = ES.input("digite o primeiro saldo");
		int saldo =ES.ToInt(s);
		saldos[0] = saldo;
		s = ES.input("digite o segundo saldo");
		saldos[1] = saldo;
		s = ES.input("digite o terceiro saldo");
		saldos[2] = saldo;
		boolean sair = false;
		while (!sair) {
			ES.print("\n opcao 1. Consultar saldo conta 1 ");
			ES.print("\n opcao 2. Consultar saldo conta 2 ");
			ES.print("\n opcao 3. Consultar saldo conta 3 ");
			ES.print("\n opcao 4. deposita R$10 na conta 1 ");
			ES.print("\n opcao 5. deposita R$10 na conta 2 ");
			ES.print("\n opcao 6. deposita R$10 na conta 3 ");
			ES.print("\n opcao 7. Saca R$3 da conta 1 ");
			ES.print("\n opcao 8. Saca R$3 da conta 2 ");
			ES.print("\n opcao 9. Saca R$3 da conta 3 ");
			ES.print("\n opcao 10. sair ");
			String op = ES.input("\n escolha uma opcao");
			if ( op.equals("1")) {
				ES.print("saldo atual: " + saldos[0]); 
				} 
			else if ( op.equals("2")){
					ES.print("saldo atual: " + saldos[1]);
				}  
			else if ( op.equals("3")){
				ES.print("saldo atual: " + saldos[2]);
				}  
			else if ( op.equals("4")){
				saldos[0] += 10;
				ES.print("deposito de R$10 efetuado");
				}  
			else if ( op.equals("5")){
				saldos[1] += 10;
				ES.print("deposito de R$10 efetuado");
				}  
			else if ( op.equals("6")){
				saldos[2] += 10;
				ES.print("deposito de R$10 efetuado");
				}  
			else if ( op.equals("7")){
				saldos[0] -= 3;
			ES.print("Saque de R$3 efetuado");
				}  
			else if ( op.equals("8")){
				saldos[1] -= 3;
				ES.print("Saque de R$3 efetuado");
				}  
			else if ( op.equals("9")){
				saldos[2] -= 3;
				ES.print("Saque de R$3 efetuado");
				} 
			else {
				ES.print("\n obrigado por usar nossos ervicos");
				sair = true;
				}
			}
		}
}