import static javax.swing.JOptionPane.*;

class Triangulo{
	
	public static void main(String[] args) {
		String msg;
		double hipotenusa;
		float cateto1;
		float cateto2;
		
		msg = showInputDialog("digite o primeiro cateto");
		cateto1 = Float.parseFloat(msg);
		msg = showInputDialog("digite o segundo cateto");
		cateto2 = Float.parseFloat(msg);
		hipotenusa = Math.sqrt( Math.pow(cateto1,2)*Math.pow(cateto2,2));
		showMessageDialog(null,"A hipotenusa é: " + hipotenusa);
	}
}