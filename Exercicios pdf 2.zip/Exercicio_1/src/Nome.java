import static javax.swing.JOptionPane.*;

class Nome{
	public static void main(String[] args) {
		String nome;
		String sobrenome;
		
		nome = showInputDialog("digite seu nome");
		sobrenome = showInputDialog("digite seu sobrenome");
		
		showMessageDialog(null,nome.length());
		showMessageDialog(null, sobrenome.length());
		showMessageDialog(null, nome.charAt(0));
		showMessageDialog(null, sobrenome.charAt(0));
		showMessageDialog(null, nome + " " + sobrenome);
	}
}