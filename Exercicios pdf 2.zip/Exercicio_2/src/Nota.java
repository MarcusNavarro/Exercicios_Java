import static javax.swing.JOptionPane.*;

class Nota{
	public static void main(String[] args) {
		String  media;
		String frequencia;
		float N_media;
		float N_frequencia;
		media = showInputDialog("digite sua nota");
		N_media = Float.parseFloat(media);
		frequencia = showInputDialog("digite sua frequencia");
		N_frequencia = Float.parseFloat(frequencia);
		
		if(N_frequencia > 7.5) {
			if (N_media >= 7.5) {
				showMessageDialog(null, "aprovado");
				}
			else {
				showMessageDialog(null,"Exame");
			}
			
		}
		else {
			showMessageDialog(null, "Reprovado");
		}
		
		
	}
}