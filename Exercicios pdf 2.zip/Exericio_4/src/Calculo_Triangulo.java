import static javax.swing.JOptionPane.*;


class Calculo_Triangulo{
	
	public static void main(String[] args) {
		String aux;
		float lado_a;
		float lado_b;
		float lado_c;
		
		aux = showInputDialog("digite o primeiro lado");
		lado_a = Float.parseFloat(aux);
		aux = showInputDialog("digite o segundo lado");
		lado_b = Float.parseFloat(aux);
		aux = showInputDialog("digite o terceiro lado");
		lado_c = Float.parseFloat(aux);
		if (lado_a < lado_b + lado_c) {
			if (lado_b < lado_a + lado_c) {
				if(lado_c < lado_a + lado_b) {
					
						}
					}
		showMessageDialog(null,"é um triangulo");
		}
	}
}